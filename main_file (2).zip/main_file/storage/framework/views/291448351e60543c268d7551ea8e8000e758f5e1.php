<?php
use App\Facades\UtilityFacades;
$logo = asset(Storage::url('uploads/logo/'));
$company_favicon = UtilityFacades::getValByName('company_favicon');
$settings = Utility::settings();

if (isset($settings['color'])) {
    $primary_color = $settings['color'];
    if ($primary_color != '') {
        $color = $primary_color;
    } else {
        $color = 'theme-1';
    }
} else {
    $color = 'theme-1';
}
?>
<!DOCTYPE html>
<html lang="en" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
    dir="<?php echo e(env('SITE_RTL') == 'on' ? 'rtl' : ''); ?>">

<head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
    
    <link rel="icon"
        href="<?php echo e($logo . (isset($company_favicon) && !empty($company_favicon) ? $company_favicon : 'favicon.png')); ?>"
        type="image" sizes="16x16">
    <?php if(env('SITE_RTL') == 'on'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-rtl.css')); ?>">
        
    <?php endif; ?>
    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/notifier.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/tabler-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/material.css')); ?>">

    <!-- vendor css -->
    <?php if(isset($settings['dark_mode'])): ?>
        <?php if($settings['dark_mode'] == 'on'): ?>
            <link rel="stylesheet" href="<?php echo e(asset('assets/css/style-dark.css')); ?>">
        <?php else: ?>
            <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" id="main-style-link">
        <?php endif; ?>
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" id="main-style-link">
    <?php endif; ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/customizer.css')); ?>">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">

</head>

<body class="<?php echo e($color); ?>">
    <!-- [ auth-signup ] start -->
    <div class="auth-wrapper auth-v1">
        <div class="bg-auth-side bg-primary"></div>
        <div class="auth-content">
            <div class="row align-items-center justify-content-center text-start">
                <div class="col-xl-6 text-center cust-margin">
                    <div class="mx-3 mx-md-5 mt-5">

                        <?php if(isset($settings['dark_mode'])): ?>
                            <?php if($settings['dark_mode'] == 'on'): ?>
                                <img src="<?php echo e($logo . 'dark_logo.png'); ?>" class="navbar-brand-img app_logo" alt="logo">
                            <?php else: ?>
                                <img src="<?php echo e($logo . 'light_logo.png'); ?>" class="navbar-brand-img app_logo"
                                    alt="logo">
                            <?php endif; ?>
                        <?php else: ?>
                            <img src="<?php echo e($logo . 'light_logo.png'); ?>" class="navbar-brand-img app_logo" alt="logo">
                        <?php endif; ?>
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>
                    <footer class="dash-footer">
                        <div class="footer-wrapper">
                            <span class="text-muted">
                                <?php if(isset($settings['dark_mode'])): ?>
                                    <?php if($settings['dark_mode'] == 'on'): ?>
                                        <img src="<?php echo e($logo . 'light_logo.png'); ?>" class="navbar-brand-img app_logo"
                                            alt="logo">
                                            <?php else: ?>
                                            <img src="<?php echo e($logo . 'dark_logo.png'); ?>" class="navbar-brand-img app_logo"
                                            alt="logo">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img src="<?php echo e($logo . 'dark_logo.png'); ?>" class="navbar-brand-img app_logo"
                                        alt="logo">
                                <?php endif; ?>
                                
                                
                            </span>
                            <div class="ms-auto">Powered by&nbsp;
                                
                                &copy; <?php echo e(date('Y')); ?> <a href="#" class="fw-bold ms-1"
                                    target="_blank"><?php echo e(config('app.name')); ?>

                            </div>
                        </div>
                    </footer>
                </div>
            </div>

            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

            <script src="<?php echo e(asset('assets/js/vendor-all.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/plugins/bootstrap.min.js')); ?>"></script>
            <script src="<?php echo e(asset('assets/js/plugins/feather.min.js')); ?>"></script>

            <script src="<?php echo e(asset('assets/js/plugins/notifier.js')); ?>"></script>


            <script>
                <?php if(session('failed')): ?>
                    notifier.show('Sorry!', '<?php echo e(session('failed')->first()); ?>', 'danger',
                        '<?php echo e(asset('assets/images/notification/high_priority-48.png')); ?>', 4000);
                <?php endif; ?>

                <?php if(session('errors')): ?>
                    notifier.show('Sorry!', '<?php echo e(session('errors')->first()); ?>', 'danger',
                        '<?php echo e(asset('assets/images/notification/high_priority-48.png')); ?>', 4000);
                <?php endif; ?>

                <?php if(session('success')): ?>
                    notifier.show('Success', '<?php echo e(session('success')->first()); ?>', 'success',
                        '<?php echo e(asset('assets/images/notification/ok-48.png')); ?>', 4000);
                <?php endif; ?>
                <?php if(session('successful')): ?>
                    notifier.show('Success', '<?php echo e(session('success')->first()); ?>', 'success',
                        '<?php echo e(asset('assets/images/notification/ok-48.png')); ?>', 4000);
                <?php endif; ?>

                <?php if(session('warning')): ?>
                    notifier.show('Warning!', '<?php echo e(session('warning')->first()); ?>', 'warning',
                        '<?php echo e(asset('assets/images/notification/medium_priority-48.png')); ?>', 4000);
                <?php endif; ?>

                <?php if(session('status')): ?>
                    notifier.show('Success', '<?php echo e(session('status')->first()); ?>', 'info',
                        '<?php echo e(asset('assets/images/notification/ok-48.png')); ?>', 4000);
                <?php endif; ?>
            </script>

            <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH /var/www/html/CCProducts/Craft/Craft-Laravel-Admin-Panel/main_file/resources/views/layouts/auth.blade.php ENDPATH**/ ?>