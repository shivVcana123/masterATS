<?php
use App\Facades\UtilityFacades;
$users = \Auth::user();
$currantLang = $users->currentLanguage();
$languages = UtilityFacades::languages();
$profile = asset(Storage::url('uploads/avatar/'));
?>

 <header class="dash-header transprent-bg">
    <div class="header-wrapper">
      <div class="ms-auto ml-0">
        <ul class="list-unstyled">
            <li class="dropdown dash-h-item drp-language">
                <a
                  class="dash-head-link dropdown-toggle arrow-none me-0"
                  data-bs-toggle="dropdown"
                  href="#"
                  role="button"
                  aria-haspopup="false"
                  aria-expanded="false"
                >
                  <i class="ti ti-world nocolor"></i>
                  <span class="drp-text hide-mob"><?php echo e(Str::upper($currantLang)); ?></span>
                  <i class="ti ti-chevron-down drp-arrow nocolor"></i>
                </a>
                <div class="dropdown-menu dash-h-dropdown dropdown-menu-end">
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item <?php if($language == $currantLang): ?> text-danger <?php endif; ?>"
                        href="<?php echo e(route('change.language', $language)); ?>"><?php echo e(Str::upper($language)); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </li>
            <li class="dropdown dash-h-item">
                <a class="dash-head-link custom-header dropdown-toggle arrow-none" data-bs-toggle="dropdown"
                    href="#" role="button" aria-haspopup="false" aria-expanded="false" >
                    <img class="rounded-circle" width="35px"
                    
                    src="<?php echo e($profile . '/avatar.png'); ?>">

                    <span>
                        <h6 class="d-inline-block ps-2"><?php echo e(Auth::user()->name); ?></h6>
                        <i class="ti ti-chevron-down drp-arrow nocolor"></i>
                    </span>
                </a>
                <div class="dropdown-menu dash-h-dropdown dropdown-menu-end">
                    <a href="<?php echo e(route('profile')); ?>" class="dropdown-item">
                        <i class="ti ti-user"></i> <span><?php echo e(__('Profile')); ?></span>
                    </a>
                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <a class="dropdown-item" href="<?php echo e(route('settings.index')); ?>">
                        <i class="ti ti-settings"></i>
                            <span><?php echo e(__('Settings')); ?></span>
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                        class="dropdown-item has-icon">
                        <i class="ti ti-power"></i> <?php echo e(__('Logout')); ?>

                    </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>

                </div>
            </li>
          
        </ul>
      </div>

    </div>
  </header>
<?php /**PATH /var/www/html/CCProducts/Craft/Craft-Laravel-Admin-Panel/main_file/resources/views/partial/header.blade.php ENDPATH**/ ?>