<?php
$users = \Auth::user();
$currantLang = $users->currentLanguage();
$logo = asset(Storage::url('uploads/logo/'));
$settings = Utility::settings();

?>

<!-- [ navigation menu ] start -->
<nav class="dash-sidebar light-sidebar transprent-bg">
    <div class="navbar-wrapper">
        <div class="m-header">
            <a href="<?php echo e(route('home')); ?>" class="b-brand">
                <!-- ========   change your logo hear   ============ -->
                
                <?php if(isset($settings['dark_mode'])): ?>
                    <?php if($settings['dark_mode'] == 'on'): ?>
                        <img class="c-sidebar-brand-full pt-3 mt-2 mb-1"
                            src="<?php echo e($logo . (isset($company_logo) && !empty($company_logo) ? $company_logo : 'light_logo.png')); ?>"
                            height="46" class="navbar-brand-img">
                    <?php else: ?>
                        <img class="c-sidebar-brand-full pt-3 mt-2 mb-1"
                            src="<?php echo e($logo . (isset($company_logo) && !empty($company_logo) ? $company_logo : 'dark_logo.png')); ?>"
                            height="46" class="navbar-brand-img">
                    <?php endif; ?>
                <?php else: ?>
                    <img class="c-sidebar-brand-full pt-3 mt-2 mb-1"
                        src="<?php echo e($logo . (isset($company_logo) && !empty($company_logo) ? $company_logo : 'dark_logo.png')); ?>"
                        height="46" class="navbar-brand-img">
                <?php endif; ?>
                
            </a>
        </div>
        <div class="navbar-content active dash-trigger ps ps--active-y">
            <ul class="dash-navbar" style="display: block;">
                <li class="dash-item dash-hasmenu <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                    <a class="dash-link" href="<?php echo e(url('/')); ?>">
                        <span class="dash-micon"><i class="ti ti-home"></i></span>
                        <span class="dash-mtext custom-weight"><?php echo e(__('Dashboard')); ?></span>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-user')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('users.index')); ?>">
                            <span class="dash-micon"><i class="ti ti-user"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Users')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-role')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('roles*') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('roles.index')); ?>">
                            <span class="dash-micon"><i class="ti ti-key"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Roles')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-permission')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('permission*') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('permission.index')); ?>">
                            <span class="dash-micon"><i class="ti ti-lock"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Permissions')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-module')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('modules*') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('modules.index')); ?>">
                            <span class="dash-micon"><i class="ti ti-subtask"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Modules')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('settings*') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('settings.index')); ?>">
                            <span class="dash-micon"><i class="ti ti-settings"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Settings')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-langauge')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('index') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('index')); ?>">
                            <span class="dash-micon"><i class="ti ti-world"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Language')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <li class="dash-item dash-hasmenu <?php echo e(request()->is('home*') ? 'active' : ''); ?>">
                        <a class="dash-link" href="<?php echo e(route('io_generator_builder')); ?>">
                            <span class="dash-micon"><i class="ti ti-3d-cube-sphere"></i></span>
                            <span class="dash-mtext custom-weight"><?php echo e(__('Crud')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>

        </div>
    </div>
</nav>
<!-- [ navigation menu ] end -->
<?php /**PATH /var/www/html/CCProducts/Craft/Craft-Laravel-Admin-Panel/main_file/resources/views/partial/nav-builder.blade.php ENDPATH**/ ?>