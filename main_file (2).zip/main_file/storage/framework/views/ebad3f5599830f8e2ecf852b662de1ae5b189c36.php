 <script>
     <?php if(session('failed')): ?>
         notifier.show('Sorry!', '<?php echo e(session('failed')); ?>', 'danger',
             '<?php echo e(asset('assets/images/notification/high_priority-48.png')); ?>', 4000);
     <?php endif; ?>

     <?php if(session('errors')): ?>
         notifier.show('Sorry!', '<?php echo e(session('errors')); ?>', 'danger',
             '<?php echo e(asset('assets/images/notification/high_priority-48.png')); ?>', 4000);
     <?php endif; ?>

     <?php if(session('success')): ?>
         notifier.show('Success', '<?php echo e(session('success')); ?>', 'success',
             '<?php echo e(asset('assets/images/notification/ok-48.png')); ?>', 4000);
     <?php endif; ?>
     <?php if(session('successful')): ?>
         notifier.show('Success', '<?php echo e(session('success')); ?>', 'success',
             '<?php echo e(asset('assets/images/notification/ok-48.png')); ?>', 4000);
     <?php endif; ?>

     <?php if(session('warning')): ?>
         notifier.show('Warning!', '<?php echo e(session('warning')); ?>', 'warning',
             '<?php echo e(asset('assets/images/notification/medium_priority-48.png')); ?>', 4000);
     <?php endif; ?>

     <?php if(session('status')): ?>
         notifier.show('Success', '<?php echo e(session('status')); ?>', 'info',
             '<?php echo e(asset('assets/images/notification/ok-48.png')); ?>', 4000);
     <?php endif; ?>

     $(document).on('click', '.delete-action', function() {
         var form_id = $(this).attr('data-form-id')
         $.confirm({
             title: '<?php echo e(__('Alert !')); ?>',
             content: '<?php echo e(__('Are You sure ?')); ?>',
             buttons: {
                 confirm: function() {
                     $("#" + form_id).submit();
                 },
                 cancel: function() {}
             }
         });
     });
 </script>
<?php /**PATH /var/www/html/CCProducts/Craft/Craft-Laravel-Admin-Panel/main_file/resources/views/layouts/includes/alerts.blade.php ENDPATH**/ ?>