<?php $__env->startSection('title'); ?>
    <?php echo e(__('Login')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <div class="card mt-5">
                        <div class="card-body mx-auto">
                            <div class="">
                                <h4 class="text-primary mb-3">Login</h4>
                            </div>

                            <div class="text-start">
                                <form method="POST" class="needs-validation" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group mb-3">
                                        <label class="form-label"><?php echo e(__('E-mail address')); ?></label>
                                        <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"
                                            id="email" placeholder="<?php echo e(__('E-mail address')); ?>" onfocus />
                                    </div>


                                    <div class="form-group mb-3">
                                        <label class="form-label float-start"><?php echo e(__('Password')); ?></label>
                                        <div class="float-end">
                                            <a href="<?php echo e(route('password.request')); ?>" class="text-small">
                                                <?php echo e(__('Forgot Password ?')); ?>

                                            </a>
                                        </div>
                                        <input type="password" class="form-control" name="password"
                                            placeholder="<?php echo e(__('Password')); ?>" />
                                    </div>


                                    <div class="form-group mb-4">
                                        <div class="form-check form-switch">
                                            <input type="checkbox" name="remember" class="form-check-input"
                                                value="<?php echo e(old('remember')); ?>" id="customswitch1" />
                                            <label class="form-check-label"
                                                for="customswitch1"><?php echo e(__('Remember me')); ?></label>
                                        </div>
                                    </div>

                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-gradient-primary btn-block mt-2">
                                            <?php echo e(__('Sign In')); ?> </button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- [ auth-signup ] end -->
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/CCProducts/Craft/Craft-Laravel-Admin-Panel/main_file/resources/views/auth/login.blade.php ENDPATH**/ ?>