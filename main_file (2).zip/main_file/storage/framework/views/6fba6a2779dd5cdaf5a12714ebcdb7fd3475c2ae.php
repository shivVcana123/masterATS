<?php $__env->startSection('title'); ?>
    <?php echo e(__(' Dashboard')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- [ breadcrumb ] start -->

    <!-- [ breadcrumb ] end -->
    <!-- [ Main Content ] start -->
    <div class="row">
        <!-- [ sample-page ] start -->
        <!-- analytic card start -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-user')): ?>
        <div class="col-xl-3 col-md-12">
            <a href="users">
                <div class="card comp-card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="m-b-0 text-muted"><?php echo e(__('Total Users')); ?></h6>
                                <h3 class="m-b-5"><?php echo e($user); ?></h3>
                            </div>
                            <div class="col-auto">
                                <i class="ti ti-users bg-primary text-white d-block"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-role')): ?>
        <div class="col-xl-3 col-md-12">
            <a href="roles">
                <div class="card comp-card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="m-b-0 text-muted"><?php echo e(__('Total Role')); ?></h6>
                                <h3 class="m-b-5"><?php echo e($role); ?></h3>
                            </div>
                            <div class="col-auto">
                                <i class="ti ti-key bg-info text-white d-block"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-module')): ?>
        <div class="col-xl-3 col-md-12">
            <a href="modules">
                <div class="card comp-card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="m-b-0 text-muted"><?php echo e(__('Total Module')); ?></h6>
                                <h3 class="m-b-5"><?php echo e($modual); ?></h3>
                            </div>
                            <div class="col-auto">
                                <i class="ti ti-users bg-success text-white d-block"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-langauge')): ?>
        <div class="col-xl-3 col-md-12">
            <a href="language">
                <div class="card comp-card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="m-b-0 text-muted"><?php echo e(__('Total Languages')); ?></h6>
                                <h3 class="m-b-5"><?php echo e($languages); ?></h3>
                            </div>
                            <div class="col-auto">
                                <i class="ti ti-world bg-danger text-white d-block"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <?php endif; ?>

        <!-- project-ticket end -->

        
        <div class="col-lg-12 ">
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-5">
                            <h4 class="card-title mb-0"><?php echo e('Users'); ?></h4>
                        </div>

                        <div class="col-sm-7 d-none d-md-block">

                            <div class="btn-group btn-group-toggle float-end mr-3" role="group" data-toggle="buttons">
                                <label class="btn btn-light-primary active" for="option1" id="option1" >
                                    <input id="option1" type="radio" class="btn-ckeck" name="options" autocomplete="off" checked="">
                                    <?php echo e(__('Month')); ?>

                                </label>
                                <label class="btn btn-light-primary" for="option2" id="option2">
                                    <input id="option2" type="radio" class="btn-ckeck" name="options" autocomplete="off"> <?php echo e(__('Year')); ?>

                                </label>
                            </div>

                        </div>
                    </div>
                    <div class="c-chart-wrapper chartbtn">
                        <canvas class="chart" id="main-chart" height="300"></canvas>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

    </div>
    <!-- [ Main Content ] end -->
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('javascript'); ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/coreui-chartjs.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    <script>
        $(document).on("click", "#option2", function() {
            getChartData('year');
        });

        $(document).on("click", "#option1", function() {
            getChartData('month');
        });
        $(document).ready(function() {
            getChartData('month');
        })

        function getChartData(type) {

            $.ajax({
                url: "<?php echo e(route('get.chart.data')); ?>",
                type: 'POST',
                data: {
                    type: type,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },

                success: function(result) {
                    mainChart.data.labels = result.lable;
                    mainChart.data.datasets[0].data = result.value;
                    mainChart.update()
                },
                error: function(data) {
                    console.log(data.responseJSON);
                }
            });
        }
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/CCProducts/Craft/Craft-Laravel-Admin-Panel/main_file/resources/views/dashboard/homepage.blade.php ENDPATH**/ ?>