
<link href="{{ asset('vendor/datatables/dataTables.bootstrap.min.css') }}" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('vendor/datatables/buttons.bootstrap.min.css') }}">
<link href="{{ asset('css/style.css') }}" rel="stylesheet">

