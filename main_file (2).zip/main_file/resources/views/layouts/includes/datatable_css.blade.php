<link rel="stylesheet" href="{{ asset('vendor/plugins/datatable/css/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/datatables/buttons.bootstrap.min.css') }}">
